package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class DropFood implements Behavior {
	static final double WHITE = 0.45;
	static final double BLACK = 0.1;
	static final double BLUE = 0.15;
	private boolean suppressed = false;
	static final int SPEED = 200;
	private Filter sample;
	private boolean done = false;

	public DropFood(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		System.out.println("in drop food");
		Motor.A.rotate(2160);
		done = true;
		suppress();
		Motor.A.stop();
	}
}
