package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class Main4 {

	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new CrossBridge(sample);
		Behavior b2 = new MoveToFood(sample);
		Behavior b3 = new PickUpFood(sample);
		Behavior b4 = new LookforPath(sample);
		Behavior b5 = new CrossBridgeAgain(sample);
		Behavior b6 = new ApproachPillar(sample);
		Behavior b7 = new DropFood(sample);
		Behavior b8 = new MoveToPath(sample);
		Behavior[] bArray = { b7, b6, b5, b4, b3, b2, b1, b8, b7, b6, b5, b4, b3, b2, b1 };
		Arbitrator arby = new Arbitrator(bArray);
		arby.start();
	}
}
