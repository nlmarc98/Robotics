package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;

public class MoveToFood implements Behavior {
	static final int SPEED = 100;
	static final double DIST_TO_PILLAR = 0.4;
	private boolean suppressed = false;
	private Filter sample;
	private boolean done = false;

	public MoveToFood(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double dist;
		while (!suppressed) {
			System.out.println("in move to object");
			dist = sample.distanceValue();
			if (dist < 0.05) {
				// Stop with approaching when the object is within a range of 5
				// cm
				done = true;
				suppress();
			} else if (dist > DIST_TO_PILLAR) {
				// Start driving in circles whenever the object is out of sight.
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			} else {
				// Slowly approach the object
				Motor.B.setSpeed(SPEED);
				Motor.B.forward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			}
			Thread.yield();
		}
		Motor.B.stop();
		Motor.C.stop();
	}
}
