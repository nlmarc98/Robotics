package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class LookforPath implements Behavior {
	static final double WHITE = 0.35;
	static final int SPEED = 200;
	private boolean suppressed = false;
	private Filter sample;
	private boolean done = false;

	public LookforPath(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue = sample.redValue();
		System.out.println("In lookforpath");
		// Make a turn
		Motor.B.rotate(800);
		Motor.C.rotate(-800);
		Motor.B.stop();
		Motor.C.stop();
		Motor.B.setSpeed(SPEED);
		Motor.C.setSpeed(SPEED + 100);
		// Robot searches for path
		while (colorValue < WHITE - 0.15) {
			Motor.B.forward();
			Motor.C.forward();
		}
		done = true;
		suppress();
		Motor.B.stop();
		Motor.C.stop();
	}
}
