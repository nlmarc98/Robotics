package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class Main4 {

	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new CrossBridge(sample);
		Behavior b2 = new MoveToFood(sample);
		Behavior b3 = new PickUpFood();
		Behavior b4 = new LookforPath(sample);
		Behavior b5 = new CrossBridgeAgain(sample);
		Behavior b6 = new ApproachPillar(sample);
		Behavior b7 = new DropFood();
		Behavior b8 = new MoveToPath(sample);
		Behavior b9 = new CrossBridge(sample);
		Behavior b10 = new MoveToFood(sample);
		Behavior b11 = new PickUpFood();
		Behavior b12 = new LookforPath(sample);
		Behavior b13 = new CrossBridgeAgain(sample);
		Behavior b14 = new ApproachPillar(sample);
		Behavior b15 = new DropFood();
		Behavior[] bArray = { b15, b14, b13, b12, b11, b10, b9, b8, b7, b6, b5, b4, b3, b2, b1 };
		Arbitrator arby = new Arbitrator(bArray);
		arby.start();
	}
}
