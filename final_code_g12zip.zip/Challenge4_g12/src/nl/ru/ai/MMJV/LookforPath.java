package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;

public class LookforPath implements Behavior {
	static final double WHITE = 0.35;
	static final int SPEED = 200;
	private boolean suppressed = false;
	private Filter sample;
	private boolean done = false;

	public LookforPath(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		System.out.println("LookForPath");
		suppressed = false;
		double colorValue = sample.redValue();
		// Make a turn
		Motor.B.rotate(800);
		Motor.C.rotate(-800);
		Motor.B.stop();
		Motor.C.stop();
		Motor.B.setSpeed(SPEED);
		Motor.C.setSpeed(SPEED + 100);
		// Robot searches for path
		while (!suppressed) {
			if (colorValue < WHITE - 0.15) {
				done = true;
				suppress();
			} else {
				Motor.B.forward();
				Motor.C.forward();
			}
		}

		Motor.B.stop();
		Motor.C.stop();
	}
}
