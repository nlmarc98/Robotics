package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class MoveToPath implements Behavior {
	static final double WHITE = 0.35;
	static final int SPEED = 200;
	private boolean suppressed = false;
	private Filter sample;
	private boolean done = false;

	public MoveToPath(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		System.out.println("MoveToPath");
		suppressed = false;
		double colorValue = sample.redValue();
		// Make a turn
		Motor.B.rotate(720);
		Motor.C.rotate(-720);
		Motor.B.stop();
		Motor.C.stop();
		Motor.B.setSpeed(SPEED);
		Motor.C.setSpeed(SPEED);
		// Robot searches for path
		while (!suppressed) {
			if (colorValue < WHITE - 0.15) {
				Motor.B.forward();
				Motor.C.forward();
				Delay.msDelay(500);
				done = true;
				suppress();
			} else {
				Motor.B.forward();
				Motor.C.forward();
			}
		}

		Motor.B.stop();
		Motor.C.stop();
	}
}
