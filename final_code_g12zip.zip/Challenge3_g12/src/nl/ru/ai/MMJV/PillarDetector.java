package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class PillarDetector implements Behavior {
	static final int SPEED = 75;
	static final double WHITE = ColorStore.WHITE;
	static final double DIST_TO_PILLAR = 0.8;
	private boolean suppressed = false;
	private Filter sample;

	public PillarDetector(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return true;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double dist;
		double redValue;
		double timer = 0;
		while (!suppressed) {
			dist = sample.distanceValue();
			redValue = sample.redValue();
			// If you are at the edge of the environment, turn around
			if (redValue > WHITE-0.05 && dist > 0.1) {
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
				timer = 0;
				Delay.msDelay(3500);
				// If no pillar is in sight, turn around and increment a timer
			} else if (dist >= DIST_TO_PILLAR) {
				timer += 1;
				// If the timer passes a threshold, move forward slightly and
				// try searching again
				if (timer > 1000) {
					Motor.B.setSpeed(SPEED);
					Motor.B.forward();
					Motor.C.setSpeed(SPEED);
					Motor.C.forward();
					Delay.msDelay(5000);
					timer = 0;
				}
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			}
			// If you are close to a pillar, suppress
			else if (dist <= 0.05) {
				suppress();
			}
			// Otherwise, move towards the pillar in sight
			else {
				Motor.B.setSpeed(SPEED);
				Motor.B.forward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
				timer = 0;
			}
			Thread.yield();
		}
		
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}
}
