package nl.ru.ai.MMJV;

import java.io.File;

import lejos.hardware.Sound;
import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class KillOrMate implements Behavior {

	private boolean suppressed = false;
	static final int SPEED = 180;
	static final int KILLSPEED = 500;
	static final int VOLUME = 150;
	private File songRed = new File("Western theme.wav");
	private File songBlue = new File("Sexy Music.wav");
	public Filter sample;

	public KillOrMate(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		// Return true if you are close to a pillar
		return (sample.distanceValue() <= 0.05);
	}

	public void suppress() {
		suppressed = true;
	}

	/**
	 * Play the song "Western theme.wav"
	 */
	public void playRed() {
		Sound.playSample(songRed, VOLUME);
	}

	/**
	 * Play the song "Sexy Music.wav"
	 */
	public void playBlue() {
		Sound.playSample(songBlue, VOLUME);
	}

	public void action() {
		suppressed = false;
		while (!suppressed) {
			double redValue = sample.redValue();
			// If the found redValue corresponds to blue, "hug" the pillar and
			// play some music, then suppress
			if (redValue < (ColorStore.RED + ColorStore.BLUE)/2) {
				Motor.A.rotate(-700);
				playBlue();
				Motor.A.rotate(700);
				Delay.msDelay(3000);
				suppress();
			}
			// If the found redValue corresponds to red, drive backwards, play
			// music and drive forwards to tackle the pillar, then suppress
			else if (redValue > (ColorStore.RED + ColorStore.BLUE)/2) {
				playRed();
				Motor.B.setSpeed(KILLSPEED);
				Motor.C.setSpeed(KILLSPEED);
				Motor.B.forward();
				Motor.C.forward();
				Delay.msDelay(2000);
				Motor.B.stop();
				Motor.C.stop();
				Delay.msDelay(3000);
				suppress();
			}
			Thread.yield();
		}
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}

}
