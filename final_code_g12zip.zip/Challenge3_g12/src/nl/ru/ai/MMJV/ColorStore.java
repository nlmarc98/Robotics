package nl.ru.ai.MMJV;

public class ColorStore {
	public static final double WHITE = 0.50;
	public static final double RED = 0.34;
	public static final double BLUE = 0.08;
}
