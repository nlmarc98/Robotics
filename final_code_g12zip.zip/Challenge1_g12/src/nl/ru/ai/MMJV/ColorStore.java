package nl.ru.ai.MMJV;

public class ColorStore {
	public static final double WHITE_GRID = 0.45;
	public static final double BLACK_GRID = 0.08;
	public static final double WHITE_MAZE = 0.37;
	public static final double BLACK_MAZE = 0.06;
}
