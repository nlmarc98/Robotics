package nl.ru.ai.MMJV;

import java.io.File;

import lejos.hardware.Sound;
import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;

public class Finished implements Behavior {
	static final int VOLUME = 150;
	private boolean suppressed = false;
	private File song = new File("Victory Sound.wav");
	private boolean done = false;

	public Finished() {
	}

	/**
	 * Play the song "Victory Sound.wav"
	 */
	public void play() {
		Sound.playSample(song, VOLUME);
		done = true;
	}
	
	@Override
	public boolean takeControl() {
		return !done;
	}

	@Override
	public void suppress() {
		suppressed = true;
	}

	@Override
	public void action() {
		suppressed = false;
		// Spin around
		Motor.C.rotate(1440, true);
		Motor.B.rotate(-1440, true);
		// Play a song
		play();
		while (!suppressed){
			if (done)
				suppress();
			Thread.yield();
		}
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}


}