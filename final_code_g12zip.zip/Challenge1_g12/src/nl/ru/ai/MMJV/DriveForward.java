package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class DriveForward implements Behavior {
	static final int SPEED = 200;
	static final double WHITE = ColorStore.WHITE_GRID;
	private boolean suppressed = false;
	public Filter sample;
	boolean done = false;

	public DriveForward(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		// Move forward in a straight line
		Motor.B.setSpeed(SPEED);
		Motor.B.forward();
		Motor.C.setSpeed(SPEED);
		Motor.C.forward();
		while (!suppressed) {
			// As soon as you find white, turn left and suppress
			if (sample.redValue() > WHITE - 0.05) {
				done = true;
				Motor.B.setSpeed((int) (SPEED * 0.8));
				Motor.C.setSpeed((int) (SPEED * 0.8));
				Motor.B.backward();	
				Motor.C.forward();
				Delay.msDelay(300);
				suppress();
			}
			Thread.yield();
		}
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}
}
