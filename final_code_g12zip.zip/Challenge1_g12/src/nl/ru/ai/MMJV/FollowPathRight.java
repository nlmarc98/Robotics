package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class FollowPathRight implements Behavior {
	static final double WHITE = ColorStore.WHITE_GRID;
	static final double BLACK = ColorStore.BLACK_GRID;
	static final int SPEED = 250;
	static final int CORNER_TIME = 20;
	static final int NUMBER_OF_CORNERS = 2;
	private boolean suppressed = false;
	private Filter sample;
	private int cornerCount = 0;

	public FollowPathRight(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		// Return true if not all 2 inner corners (required for the last two
		// gridpoints) have been reached
		return cornerCount < NUMBER_OF_CORNERS;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue;
		double diff = WHITE - BLACK;
		double invDiff = 1 / diff;
		double BSpeed;
		double CSpeed;
		int counter = 0;
		while (!suppressed) {
			// Suppress if both inner corners have been reached
			if (cornerCount >= NUMBER_OF_CORNERS)
				suppress();
			colorValue = sample.redValue();
			// If the colorValue is white, increment the counter
			if (colorValue > WHITE - 0.1)
				counter++;
			// Otherwise, reset the counter
			else
				counter = 0;
			// If the counter passes a certain threshold, the robot is turning
			// longer than usual, meaning a corner has been reached: increment
			// the cornerCount and make a full turn
			if (counter >= CORNER_TIME) {
				if (counter == CORNER_TIME)
					cornerCount++;
				Motor.B.setSpeed((int) (SPEED * 0.8));
				Motor.C.setSpeed((int) (SPEED * 0.8));
				Motor.B.forward();
				Motor.C.backward();
				Delay.msDelay(300);
			}
			// Otherwise, keep following the right side of the path
			else {
				BSpeed = (invDiff) * colorValue - (0.1 * invDiff);
				CSpeed = -(invDiff) * colorValue + (1 + 0.1 * invDiff);
				Motor.B.setSpeed((int) (SPEED * BSpeed));
				Motor.B.forward();
				Motor.C.setSpeed((int) (SPEED * CSpeed));
				Motor.C.forward();
			}
			Delay.msDelay(10);
			Thread.yield();
		}
		Motor.B.stop();
		Motor.C.stop();
	}
}
