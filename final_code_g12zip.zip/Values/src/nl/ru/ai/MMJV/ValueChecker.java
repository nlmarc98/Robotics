package nl.ru.ai.MMJV;

public class ValueChecker {	
	
	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		while(true){
			System.out.println(sample.redValue());
		}
	}
}
