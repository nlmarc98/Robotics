package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class Race implements Behavior {
	static final double WHITE = 0.25;
	static final double BLACK = 0.02;
	static final int SPEED = 275;
	static final int BLACK_CORNER_TIME = 60;
	static final int WHITE_CORNER_TIME = 25;
	private boolean suppressed = false;
	private Filter sample;
	boolean done = false;

	public Race(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue;
		double diff = WHITE - BLACK;
		double invDiff = 1 / diff;
		double BSpeed;
		double CSpeed;
		int blackCounter = 0;
		int whiteCounter = 0;
		while (!suppressed) {
			colorValue = sample.redValue();
			// If the colorValue is black, increment the blackCounter
			if (colorValue < BLACK + 0.05)
				blackCounter++;
			// otherwise, reset the counter
			else
				blackCounter = 0;
			// If the colorValue is white, increment the whiteCounter
			if (colorValue > WHITE - 0.1)
				whiteCounter++;
			// Otherwise, reset the counter
			else
				whiteCounter = 0;
			// If the blackCounter passes a certain threshold, make a full turn
			// right
			if (blackCounter >= BLACK_CORNER_TIME) {
				Motor.B.setSpeed((int) (SPEED * 1.6));
				Motor.C.setSpeed((int) (SPEED * 0.4));
				Motor.B.forward();
				Motor.C.backward();
			}
			// If the blackCounter passes a certain threshold, make a full turn
			// left
			else if (whiteCounter >= WHITE_CORNER_TIME) {
				Motor.B.setSpeed((int) (SPEED * 0.4));
				Motor.C.setSpeed((int) (SPEED * 1.6));
				Motor.B.backward();
				Motor.C.forward();
			}
			// Otherwise, keep following the left side of the path
			else {
				BSpeed = -(invDiff) * colorValue + (1 + 0.1 * invDiff);
				CSpeed = (invDiff) * colorValue - (0.1 * invDiff);
				Motor.B.setSpeed((int) (SPEED * BSpeed));
				Motor.B.forward();
				Motor.C.setSpeed((int) (SPEED * CSpeed));
				Motor.C.forward();
			}
			Delay.msDelay(5);
			// If you are at the end of the maze, suppress
			Thread.yield();
		}
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}
}
