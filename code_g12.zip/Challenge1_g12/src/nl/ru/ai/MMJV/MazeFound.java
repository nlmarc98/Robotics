package nl.ru.ai.MMJV;

import java.io.File;

import lejos.hardware.Sound;
import lejos.robotics.subsumption.Behavior;

public class MazeFound implements Behavior {
	static final int VOLUME = 150;
	static final int SPEED = 100;
	private File song = new File("Weeeeee Sound.wav");
	private boolean suppressed = false;
	private boolean done = false;

	public MazeFound() {
	}

	/**
	 * Play the song "Weeeeee Sound.wav"
	 */
	public void play() {
		Sound.playSample(song, VOLUME);
		done = true;
	}

	@Override
	public boolean takeControl() {
		return !done;
	}
	
	@Override
	public void suppress() {
		suppressed = true;
	}

	@Override
	public void action() {
		suppressed = false;
		// Play a song and suppress
		play();
		while (!suppressed){
			if (done)
				suppress();
			Thread.yield();
		}
	}
}
