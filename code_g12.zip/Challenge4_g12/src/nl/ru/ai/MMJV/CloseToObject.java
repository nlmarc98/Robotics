package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class CloseToObject implements Behavior {
	static final double WHITE = 0.45;
	static final double BLACK = 0.1;
	static final double BLUE = 0.15;
	static final int SPEED = 200;
	private boolean suppressed = false;
	private Filter sample;

	public CloseToObject(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return sample.distanceValue() <= 0.05;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue = sample.redValue();
		// Blue check counter is 1 (or 4 in second run) when the robot has
		// already passed the first blue pillar. So when the redsensor is
		// again close to an object and sees the blue/black colorvalue it
		// knows that this object is food so it can pick up the object.
		if ((sample.getBlueCheckCounter() == 1 || sample.getBlueCheckCounter() == 4) && colorValue < BLUE) {
			sample.setBlueCheckCounter(1);
			// Close arms
			Motor.A.rotate(-2000);
			while (!suppressed) {
				Thread.yield();
			}
			// Make a turn
			Motor.B.rotate(-400);
			Motor.C.rotate(400);
			while (!suppressed) {
				Thread.yield();
			}
			int switcher = 0;
			Motor.B.setSpeed(SPEED);
			Motor.C.setSpeed(SPEED);
			// Robot searches for path
			while (colorValue < WHITE) {
				Motor.B.forward();
				Motor.C.forward();
				Delay.msDelay(1000);
				if (switcher == 0) {
					Motor.B.rotate(-100);
					Motor.C.rotate(100);
					switcher += 1;
				} else {
					Motor.B.rotate(100);
					Motor.C.rotate(-100);
					switcher -= 1;
				}
			}
			suppress();
		}
		// Blue check counter is 2 (or 5 in second run) so the robot has already
		// seen the blue pillar and a food piece. So whenever it again detects
		// blue/black it is 'home', so the food can be dropped.
		else if ((sample.getBlueCheckCounter() == 2 || sample.getBlueCheckCounter() == 5) && colorValue < BLUE) {
			Motor.A.rotate(2000);
			sample.setBlueCheckCounter(1);
		} else if (colorValue < BLUE) {
			// The first pillar is blue so the robot can continue this path
			// looking for food.
			sample.setBlueCheckCounter(1);
			Motor.B.setSpeed(SPEED);
			Motor.C.setSpeed(SPEED + 20);
			while (colorValue < WHITE)
				Motor.B.backward();
			Motor.C.backward();
			Motor.A.rotate(2160);
			suppress();
		}
		// Otherwise, the pillar is red, so the robot has to make a turn
		else {
			Motor.B.setSpeed(SPEED + 20);
			Motor.C.setSpeed(SPEED);
			while (colorValue > WHITE)
				Motor.B.backward();
			Motor.C.backward();
			suppress();
		}
		Motor.B.stop();
		Motor.C.stop();
	}
}
