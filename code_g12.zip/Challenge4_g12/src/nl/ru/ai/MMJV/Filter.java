package nl.ru.ai.MMJV;

public class Filter {
	private static final int NUMBER_OF_SAMPLES = 100;
	public SampleRetrieval sample;
	public int blueCounter;

	public Filter(SampleRetrieval s) {
		this.sample = s;
	}

	public float redValue() {
		// Get the average of 100 redSample values and return it to the caller
		float sum = 0;
		for (int i = 0; i < NUMBER_OF_SAMPLES; i++) {
			sum += sample.redSample()[0];
		}
		return sum / NUMBER_OF_SAMPLES;
	}

	public float rgbValue() {
		// Get the average of 100 rgbSample values and return it to the caller
		float sum = 0;
		for (int i = 0; i < NUMBER_OF_SAMPLES; i++) {
			sum += sample.rgbSample()[0];
		}
		return sum / NUMBER_OF_SAMPLES;
	}

	public float distanceValue() {
		// Get the average of 100 distanceSample values and return it to the caller
		float sum = 0;
		for (int i = 0; i < NUMBER_OF_SAMPLES; i++) {
			sum += sample.distanceSample()[0];
		}
		return sum / NUMBER_OF_SAMPLES;
	}

	public int setBlueCheckCounter(int count) {
		// Increment the blueCounter by an int and then return it to the caller
		blueCounter += count;
		return blueCounter;
	}

	public int getBlueCheckCounter() {
		// Return the blueCounter
		return blueCounter;
	}
}
