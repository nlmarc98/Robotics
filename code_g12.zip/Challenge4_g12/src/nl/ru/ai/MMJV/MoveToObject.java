package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;

public class MoveToObject implements Behavior {
	static final int SPEED = 100;
	static final double DIST_TO_PILLAR = 0.4;
	private boolean suppressed = false;
	private Filter sample;

	public MoveToObject(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		// Return true if the robot is close to an object
		return sample.distanceValue()<0.30;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double dist;
		while (!suppressed) {
			dist = sample.distanceValue();
			// Stop with approaching when the object is within a range of 5 cm
			if (dist < 0.05)
				suppress();
			// Start driving in circles whenever the object is out of sight.
			else if (dist > DIST_TO_PILLAR) {
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			}
			// Slowly approach the object
			else {
				Motor.B.setSpeed(SPEED+100);
				Motor.B.forward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			}
			Thread.yield();
		}
		// Clean up
		Motor.B.stop();
		Motor.C.stop();
	}
}
