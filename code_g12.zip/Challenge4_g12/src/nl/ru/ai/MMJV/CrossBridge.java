package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class CrossBridge implements Behavior {
	static final double WHITE = 0.35;
	static final double BLACK = 0.1;
	static final int SPEED = 250;
	static final int CORNER_TIME = 20;
	private boolean suppressed = false;
	private Filter sample;
	private boolean done = false;

	public CrossBridge(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue;
		double diff = WHITE - BLACK;
		double invDiff = 1 / diff;
		double BSpeed;
		double CSpeed;
		int counter = 0;
		while (!suppressed) {
			colorValue = sample.redValue();
			// If the colorValue is white, increment the counter
			if (colorValue > WHITE)
				counter++;
			// Otherwise, reset the counter
			else
				counter = 0;
			// Whenever the robot is on the line longer than the threshold,
			// a sharp turn is made.
			if (counter >= CORNER_TIME) {
				Motor.B.setSpeed((int) (SPEED * 0.8));
				Motor.C.setSpeed((int) (SPEED * 0.5));
				Motor.B.forward();
				Motor.C.forward();
				Delay.msDelay(1000);
				done = true;
				suppress();
			}
			// Otherwise, keep following the right side of the path
			else {
				BSpeed = -(invDiff) * colorValue + (1 + 0.1 * invDiff);
				CSpeed = (invDiff) * colorValue - (0.1 * invDiff);
				Motor.B.setSpeed((int) (SPEED * BSpeed));
				Motor.B.forward();
				Motor.C.setSpeed((int) (SPEED * CSpeed));
				Motor.C.forward();
			}
			Delay.msDelay(10);
			Thread.yield();
		}
		Motor.B.stop();
		Motor.C.stop();
	}
}
