package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class Main4 {	
	
	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new CrossBridge(sample);
		Behavior b2 = new FollowPathToObject(sample);
		Behavior b3 = new MoveToObject (sample);
		Behavior b4 = new CloseToObject(sample);
		Behavior [] bArray = {b3, b4, b2, b1};
	    Arbitrator arby = new Arbitrator(bArray);
	    arby.start();
	}
}
