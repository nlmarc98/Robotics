package nl.ru.ai.MMJV;

import java.io.File;

import lejos.hardware.Sound;
import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class KillOrMate implements Behavior {

	private boolean suppressed = false;
	static final int SPEED = 180;
	static final int KILLSPEED = 300;
	static final int VOLUME = 150;
	private File songRed = new File("Western theme.wav");
	private File songBlue = new File("Sexy Music.wav");
	public Filter sample;

	public KillOrMate(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return (sample.distanceValue() <= 0.05);
	}

	public void suppress() {
		suppressed = true;
	}

	public void playRed() {
		Sound.playSample(songRed, VOLUME);
	}

	public void playBlue() {
		Sound.playSample(songBlue, VOLUME);
	}

	public void action() {
		suppressed = false;
		while (!suppressed) {
			double redValue = sample.redValue();
			if (redValue < 0.15) {
				Motor.A.rotate(-1000);
				playBlue();
				Motor.A.rotate(1000);
				Delay.msDelay(3000);
				suppress();
			} else if (redValue > 0.20) {
				Motor.B.setSpeed(SPEED);
				Motor.C.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.backward();
				Delay.msDelay(1000);
				Motor.C.stop();
				Motor.B.stop();
				playRed();
				Motor.B.setSpeed(KILLSPEED);
				Motor.C.setSpeed(KILLSPEED);
				Motor.B.forward();
				Motor.C.forward();
				Delay.msDelay(2000);
				Motor.B.stop();
				Motor.C.stop();
				Delay.msDelay(3000);
				suppress();
			}
			Thread.yield();
		}
		Motor.B.stop();
		Motor.C.stop();
	}

}
