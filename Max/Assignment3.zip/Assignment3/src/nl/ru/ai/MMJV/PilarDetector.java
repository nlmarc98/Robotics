package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class PilarDetector implements Behavior {
	static final int SPEED = 75;
	static final double WHITE = 0.45;
	static final double DIST_TO_PILLAR = 0.6;
	private boolean suppressed = false;
	private Filter sample;

	public PilarDetector(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return true;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double dist;
		double redValue;
		double timer = 0;
		while (!suppressed) {
			dist = sample.distanceValue();
			redValue = sample.redValue();
			if (redValue > WHITE && dist > 0.1) {
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
				timer = 0;
				Delay.msDelay(3500);
			} else if (dist >= DIST_TO_PILLAR) {
				timer += 1;
				if (timer > 1000){
					Motor.B.setSpeed(SPEED);
					Motor.B.forward();
					Motor.C.setSpeed(SPEED);
					Motor.C.forward();
					Delay.msDelay(1000);
					timer = 0;
				}
				Motor.B.setSpeed(SPEED);
				Motor.B.backward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
			} else if (dist <= 0.05) {
				suppress();
			} else {
				Motor.B.setSpeed(SPEED);
				Motor.B.forward();
				Motor.C.setSpeed(SPEED);
				Motor.C.forward();
				timer = 0;
			}
			Thread.yield();
		}
		Motor.B.stop(); // clean up
		Motor.C.stop();
	}
}
