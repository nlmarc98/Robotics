package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class ProjectFriendOrFoe {

	public static void main(String[] args) throws Exception {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new KillOrMate(sample);
		Behavior b2 = new PilarDetector(sample);
		Behavior[] bArray = {b2, b1};
		Arbitrator arby = new Arbitrator(bArray);
		arby.start();
	}
}
