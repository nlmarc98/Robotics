package nl.ru.ai.MMJV;

import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class CheckPillar implements Behavior {
	static final double WHITE = 0.45;
	static final double BLACK = 0.1;
	static final double BLUE = 0.15;
	static final int SPEED = 200;
	private boolean suppressed = false;
	private Filter sample;
	private boolean blue = false;
	private boolean red = false;

	public CheckPillar(Filter s) {
		this.sample = s;
	}

	public boolean takeControl() {
		return sample.distanceValue() <= 0.05;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		double colorValue = sample.redValue();
		if (colorValue < BLUE)
			blue = true;
		else
			red = true;
		
		while (!suppressed) {
			Thread.yield();
		}
		Motor.B.stop();
		Motor.C.stop();
	}
}
