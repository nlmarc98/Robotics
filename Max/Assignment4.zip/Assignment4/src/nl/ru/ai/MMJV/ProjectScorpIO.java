package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class ProjectScorpIO {	
	
	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new GrabberTest();
		Behavior [] bArray = {b1};
	    Arbitrator arby = new Arbitrator(bArray);
	    arby.start();
	}
}
