package nl.ru.ai.MMJV;

import java.io.File;

import lejos.hardware.Sound;
import lejos.hardware.motor.Motor;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;

public class GrabberTest implements Behavior {
	private boolean suppressed = false;
	//private Filter sample;
	private boolean done = false;

	public GrabberTest(/*Filter s*/) {
		//this.sample = s;
	}

	public boolean takeControl() {
		return !done;
	}

	public void suppress() {
		suppressed = true;
	}

	public void action() {
		suppressed = false;
		//Motor.A.rotate(-2160);
		Sound.playSample(new File("Sexy Music.wav"),150);
		//Motor.A.rotate(2160);
		while (!suppressed) {
			Thread.yield();
		}
	}
}
