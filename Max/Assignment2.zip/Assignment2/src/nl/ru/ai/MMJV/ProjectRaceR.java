package nl.ru.ai.MMJV;

import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;

public class ProjectRaceR {	
	
	public static void main(String[] args) {
		SampleRetrieval sr = new SampleRetrieval();
		Filter sample = new Filter(sr);
		Behavior b1 = new SolveMaze(sample);
		Behavior [] bArray = {b1};
	    Arbitrator arby = new Arbitrator(bArray);
	    arby.start();
	}
}
